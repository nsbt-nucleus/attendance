package com.vivek.java_testing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaTestingApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaTestingApplication.class, args);
	}
	
}
