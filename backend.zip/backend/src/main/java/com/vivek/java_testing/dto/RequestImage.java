package com.vivek.java_testing.dto;

import lombok.Data;

@Data
public class RequestImage {
    private String data;
    private String userId;
}
